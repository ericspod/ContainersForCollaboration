op_version_set = 1
class Sequential(Module):
  __parameters__ = []
  training : bool
  unit0 : __torch__.ptproto.networks.layers.convolutions.___torch_mangle_18.Convolution
  unit1 : __torch__.ptproto.networks.layers.convolutions.___torch_mangle_20.Convolution
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_21.Sequential,
    input: Tensor) -> Tensor:
    _0 = self.unit0
    _1 = self.unit1
    input0 = (_0).forward(input, )
    return (_1).forward(input0, )
