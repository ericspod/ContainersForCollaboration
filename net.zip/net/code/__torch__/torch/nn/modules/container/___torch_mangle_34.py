op_version_set = 1
class Sequential(Module):
  __parameters__ = []
  training : bool
  conv : __torch__.ptproto.networks.layers.convolutions.___torch_mangle_31.Convolution
  resunit : __torch__.ptproto.networks.layers.convolutions.___torch_mangle_33.ResidualUnit
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_34.Sequential,
    input: Tensor) -> Tensor:
    _0 = self.conv
    _1 = self.resunit
    input0 = (_0).forward(input, )
    return (_1).forward(input0, )
