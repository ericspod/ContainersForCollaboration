op_version_set = 1
class Sequential(Module):
  __parameters__ = []
  training : bool
  unit0 : __torch__.ptproto.networks.layers.convolutions.___torch_mangle_1.Convolution
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_46.Sequential,
    input: Tensor) -> Tensor:
    return (self.unit0).forward(input, )
