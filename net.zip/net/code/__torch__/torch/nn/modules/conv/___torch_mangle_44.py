op_version_set = 1
class ConvTranspose2d(Module):
  __parameters__ = ["weight", "bias", ]
  transposed : bool
  training : bool
  weight : Tensor
  bias : Tensor
  def forward(self: __torch__.torch.nn.modules.conv.___torch_mangle_44.ConvTranspose2d,
    input: Tensor,
    output_size: Optional[List[int]]=None) -> Tensor:
    if torch.ne("zeros", "zeros"):
      ops.prim.RaiseException("Exception")
    else:
      pass
    output_padding = (self)._output_padding(input, output_size, [2, 2], [1, 1], [3, 3], )
    _0 = torch.conv_transpose2d(input, self.weight, self.bias, [2, 2], [1, 1], output_padding, 1, [1, 1])
    return _0
  def _output_padding(self: __torch__.torch.nn.modules.conv.___torch_mangle_44.ConvTranspose2d,
    input: Tensor,
    output_size: Optional[List[int]],
    stride: List[int],
    padding: List[int],
    kernel_size: List[int]) -> List[int]:
    if torch.__is__(output_size, None):
      ret = [1, 1]
    else:
      output_size0 = unchecked_cast(List[int], output_size)
      k = torch.sub(torch.dim(input), 2)
      _1 = torch.eq(torch.len(output_size0), torch.add(k, 2))
      if _1:
        output_size1 = torch.slice(output_size0, 2, 9223372036854775807, 1)
      else:
        output_size1 = output_size0
      _2 = torch.ne(torch.len(output_size1), k)
      if _2:
        ops.prim.RaiseException("Exception")
      else:
        pass
      min_sizes = annotate(List[int], [])
      max_sizes = annotate(List[int], [])
      for d in range(k):
        _3 = torch.size(input, torch.add(d, 2))
        _4 = torch.mul(torch.sub(_3, 1), stride[d])
        _5 = torch.sub(_4, torch.mul(2, padding[d]))
        dim_size = torch.add(_5, kernel_size[d])
        _6 = torch.append(min_sizes, dim_size)
        _7 = torch.add(min_sizes[d], stride[d])
        _8 = torch.append(max_sizes, torch.sub(_7, 1))
      for i in range(torch.len(output_size1)):
        size = output_size1[i]
        min_size = min_sizes[i]
        max_size = max_sizes[i]
        if torch.lt(size, min_size):
          _9 = True
        else:
          _9 = torch.gt(size, max_size)
        if _9:
          ops.prim.RaiseException("Exception")
        else:
          pass
      res = annotate(List[int], [])
      for d0 in range(k):
        _10 = torch.sub(output_size1[d0], min_sizes[d0])
        _11 = torch.append(res, _10)
      ret = res
    return ret
