op_version_set = 1
class PReLU(Module):
  __parameters__ = ["weight", ]
  training : bool
  weight : Tensor
  def forward(self: __torch__.torch.nn.modules.activation.PReLU,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.prelu(input, self.weight, )
    return _0
