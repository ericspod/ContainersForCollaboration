op_version_set = 1
class InstanceNorm2d(Module):
  __parameters__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.instancenorm.___torch_mangle_3.InstanceNorm2d,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.___torch_mangle_68.instance_norm
    _1 = (self)._check_input_dim(input, )
    if self.training:
      _2 = True
    else:
      _2 = torch.__not__(False)
    _3 = _0(input, None, None, None, None, _2, 0.10000000000000001, 1.0000000000000001e-05, )
    return _3
  def _check_input_dim(self: __torch__.torch.nn.modules.instancenorm.___torch_mangle_3.InstanceNorm2d,
    input: Tensor) -> None:
    if torch.ne(torch.dim(input), 4):
      ops.prim.RaiseException("Exception")
    else:
      pass
    return None
