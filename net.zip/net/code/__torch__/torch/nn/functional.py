op_version_set = 1
def pad(input: Tensor,
    pad: List[int],
    mode: str="constant",
    value: float=0.) -> Tensor:
  _0 = __torch__.torch.nn.functional._pad_circular
  _1 = __torch__.torch.nn.functional.___torch_mangle_58._pad_circular
  _2 = __torch__.torch.nn.functional.___torch_mangle_59._pad_circular
  _3 = uninitialized(Tensor)
  _4 = torch.eq(torch.remainder(torch.len(pad), 2), 0)
  if _4:
    pass
  else:
    ops.prim.RaiseException("Exception")
  _5 = torch.le(torch.floordiv(torch.len(pad), 2), torch.dim(input))
  if _5:
    pass
  else:
    ops.prim.RaiseException("Exception")
  if torch.eq(mode, "constant"):
    _6 = torch.constant_pad_nd(input, pad, value)
  else:
    if torch.eq(value, 0):
      pass
    else:
      ops.prim.RaiseException("Exception")
    if torch.eq(torch.dim(input), 3):
      if torch.eq(torch.len(pad), 2):
        pass
      else:
        ops.prim.RaiseException("Exception")
      if torch.eq(mode, "reflect"):
        _8 = torch.reflection_pad1d(input, pad)
      else:
        if torch.eq(mode, "replicate"):
          _9 = torch.replication_pad1d(input, pad)
        else:
          if torch.eq(mode, "circular"):
            _10 = _0(input, pad, )
          else:
            ops.prim.RaiseException("Exception")
            _10 = _3
          _9 = _10
        _8 = _9
      _7 = _8
    else:
      if torch.eq(torch.dim(input), 4):
        if torch.eq(torch.len(pad), 4):
          pass
        else:
          ops.prim.RaiseException("Exception")
        if torch.eq(mode, "reflect"):
          _12 = torch.reflection_pad2d(input, pad)
        else:
          if torch.eq(mode, "replicate"):
            _13 = torch.replication_pad2d(input, pad)
          else:
            if torch.eq(mode, "circular"):
              _14 = _1(input, pad, )
            else:
              ops.prim.RaiseException("Exception")
              _14 = _3
            _13 = _14
          _12 = _13
        _11 = _12
      else:
        if torch.eq(torch.dim(input), 5):
          if torch.eq(torch.len(pad), 6):
            pass
          else:
            ops.prim.RaiseException("Exception")
          if torch.eq(mode, "reflect"):
            ops.prim.RaiseException("Exception")
            _16 = _3
          else:
            if torch.eq(mode, "replicate"):
              _17 = torch.replication_pad3d(input, pad)
            else:
              _18 = torch.eq(mode, "circular")
              if _18:
                _19 = _2(input, pad, )
              else:
                ops.prim.RaiseException("Exception")
                _19 = _3
              _17 = _19
            _16 = _17
          _15 = _16
        else:
          ops.prim.RaiseException("Exception")
          _15 = _3
        _11 = _15
      _7 = _11
    _6 = _7
  return _6
def instance_norm(input: Tensor,
    running_mean: Optional[Tensor]=None,
    running_var: Optional[Tensor]=None,
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    use_input_stats: bool=True,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _20 = torch.instance_norm(input, weight, bias, running_mean, running_var, use_input_stats, momentum, eps, True)
  return _20
def prelu(input: Tensor,
    weight: Tensor) -> Tensor:
  return torch.prelu(input, weight)
def _pad_circular(input: Tensor,
    padding: List[int]) -> Tensor:
  _21 = torch.slice(input, 0, 0, 9223372036854775807, 1)
  _22 = torch.slice(_21, 1, 0, 9223372036854775807, 1)
  _23 = torch.slice(_22, 2, 0, padding[-1], 1)
  input0 = torch.cat([input, _23], 2)
  _24 = torch.slice(input0, 0, 0, 9223372036854775807, 1)
  _25 = torch.slice(_24, 1, 0, 9223372036854775807, 1)
  _26 = torch.neg(torch.add(padding[-1], padding[-2]))
  _27 = torch.slice(_25, 2, _26, torch.neg(padding[-1]), 1)
  input1 = torch.cat([_27, input0], 2)
  if torch.gt(torch.len(padding), 2):
    _28 = torch.slice(input1, 0, 0, 9223372036854775807, 1)
    _29 = torch.slice(_28, 1, 0, 9223372036854775807, 1)
    _30 = torch.slice(_29, 2, 0, 9223372036854775807, 1)
    _31 = torch.slice(_30, 3, 0, padding[-3], 1)
    input3 = torch.cat([input1, _31], 3)
    _32 = torch.slice(input3, 0, 0, 9223372036854775807, 1)
    _33 = torch.slice(_32, 1, 0, 9223372036854775807, 1)
    _34 = torch.slice(_33, 2, 0, 9223372036854775807, 1)
    _35 = torch.neg(torch.add(padding[-3], padding[-4]))
    _36 = torch.slice(_34, 3, _35, torch.neg(padding[-3]), 1)
    input2 = torch.cat([_36, input3], 3)
  else:
    input2 = input1
  if torch.gt(torch.len(padding), 4):
    _37 = torch.slice(input2, 0, 0, 9223372036854775807, 1)
    _38 = torch.slice(_37, 1, 0, 9223372036854775807, 1)
    _39 = torch.slice(_38, 2, 0, 9223372036854775807, 1)
    _40 = torch.slice(_39, 3, 0, 9223372036854775807, 1)
    _41 = torch.slice(_40, 4, 0, padding[-5], 1)
    input5 = torch.cat([input2, _41], 4)
    _42 = torch.slice(input5, 0, 0, 9223372036854775807, 1)
    _43 = torch.slice(_42, 1, 0, 9223372036854775807, 1)
    _44 = torch.slice(_43, 2, 0, 9223372036854775807, 1)
    _45 = torch.slice(_44, 3, 0, 9223372036854775807, 1)
    _46 = torch.neg(torch.add(padding[-5], padding[-6]))
    _47 = torch.slice(_45, 4, _46, torch.neg(padding[-5]), 1)
    input4 = torch.cat([_47, input5], 4)
  else:
    input4 = input2
  return input4
