op_version_set = 1
def instance_norm(input: Tensor,
    running_mean: Optional[Tensor]=None,
    running_var: Optional[Tensor]=None,
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    use_input_stats: bool=True,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _0 = torch.instance_norm(input, weight, bias, running_mean, running_var, use_input_stats, momentum, eps, True)
  return _0
