op_version_set = 1
def predict_segmentation(logits: Tensor) -> Tensor:
  _0 = torch.eq((ops.prim.shape(logits))[1], 1)
  if _0:
    _2 = torch.slice(logits, 0, 0, 9223372036854775807, 1)
    _1 = torch._cast_Int(torch.ge(torch.select(_2, 1, 0), 0), False)
  else:
    _3, _4 = torch.max(logits, 1, False)
    _1 = _4
  return _1
