op_version_set = 1
class UNet(Module):
  __parameters__ = []
  num_classes : int
  in_channels : int
  dimensions : int
  kernel_size : int
  use_shuffle : bool
  dropout : None
  up_kernel_size : int
  norm : str
  channels : List[int]
  training : bool
  num_res_units : int
  strides : List[int]
  act : str
  net : __torch__.torch.nn.modules.container.___torch_mangle_57.Sequential
  def forward(self: __torch__.ptproto.networks.nets.unet.UNet,
    x: Tensor) -> Tuple[Tensor, Tensor]:
    _0 = __torch__.ptproto.networks.utils.predict_segmentation
    x0 = (self.net).forward(x, )
    return (x0, _0(x0, ))
