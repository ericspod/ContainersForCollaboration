op_version_set = 1
class Convolution(Module):
  __parameters__ = []
  is_transposed : bool
  out_channels : int
  in_channels : int
  training : bool
  dimensions : int
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_0.Conv2d
  def forward(self: __torch__.ptproto.networks.layers.convolutions.___torch_mangle_53.Convolution,
    input: Tensor) -> Tensor:
    return (self.conv).forward(input, )
