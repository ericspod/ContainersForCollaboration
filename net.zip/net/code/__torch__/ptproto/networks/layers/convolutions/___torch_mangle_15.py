op_version_set = 1
class ResidualUnit(Module):
  __parameters__ = []
  out_channels : int
  in_channels : int
  training : bool
  dimensions : int
  conv : __torch__.torch.nn.modules.container.___torch_mangle_14.Sequential
  residual : __torch__.torch.nn.modules.conv.___torch_mangle_9.Conv2d
  def forward(self: __torch__.ptproto.networks.layers.convolutions.___torch_mangle_15.ResidualUnit,
    x: Tensor) -> Tensor:
    res = (self.residual).forward(x, )
    cx = (self.conv).forward(x, )
    return torch.add(cx, res, alpha=1)
