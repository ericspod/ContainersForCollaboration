op_version_set = 1
class ResidualUnit(Module):
  __parameters__ = []
  out_channels : int
  in_channels : int
  training : bool
  dimensions : int
  conv : __torch__.torch.nn.modules.container.___torch_mangle_54.Sequential
  residual : __torch__.torch.nn.modules.linear.Identity
  def forward(self: __torch__.ptproto.networks.layers.convolutions.___torch_mangle_55.ResidualUnit,
    x: Tensor) -> Tensor:
    res = (self.residual).forward(x, )
    cx = (self.conv).forward(x, )
    return torch.add(cx, res, alpha=1)
