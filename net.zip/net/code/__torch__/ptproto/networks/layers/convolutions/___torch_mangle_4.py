op_version_set = 1
class Convolution(Module):
  __parameters__ = []
  is_transposed : bool
  out_channels : int
  in_channels : int
  training : bool
  dimensions : int
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_2.Conv2d
  norm : __torch__.torch.nn.modules.instancenorm.___torch_mangle_3.InstanceNorm2d
  act : __torch__.torch.nn.modules.activation.PReLU
  def forward(self: __torch__.ptproto.networks.layers.convolutions.___torch_mangle_4.Convolution,
    input: Tensor) -> Tensor:
    _0 = self.conv
    _1 = self.norm
    _2 = self.act
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    return (_2).forward(input1, )
