op_version_set = 1
class SkipConnection(Module):
  __parameters__ = []
  cat_dim : int
  training : bool
  submodule : __torch__.ptproto.networks.layers.convolutions.___torch_mangle_30.ResidualUnit
  def forward(self: __torch__.ptproto.networks.layers.simplelayers.SkipConnection,
    x: Tensor) -> Tensor:
    _0 = torch.cat([x, (self.submodule).forward(x, )], self.cat_dim)
    return _0
