op_version_set = 1
class SkipConnection(Module):
  __parameters__ = []
  cat_dim : int
  training : bool
  submodule : __torch__.torch.nn.modules.container.___torch_mangle_35.Sequential
  def forward(self: __torch__.ptproto.networks.layers.simplelayers.___torch_mangle_36.SkipConnection,
    x: Tensor) -> Tensor:
    _0 = torch.cat([x, (self.submodule).forward(x, )], self.cat_dim)
    return _0
